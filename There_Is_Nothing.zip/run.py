# This is the entry point for the program.
# Run this to run the game!

import src.loop

game = src.loop.Loop()
game.run_game()